package com.example.postest3_1915016043_mutiara

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
