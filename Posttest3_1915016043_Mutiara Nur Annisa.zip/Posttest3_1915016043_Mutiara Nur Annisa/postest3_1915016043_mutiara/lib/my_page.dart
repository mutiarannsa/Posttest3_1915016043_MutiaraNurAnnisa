import 'package:flutter/material.dart';

void main() {
  runApp(const my_page());
}

class my_page extends StatelessWidget {
  const my_page({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Posttest 3 Mutiara',
      theme: ThemeData(primarySwatch: Colors.grey),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final alamatCtrl = TextEditingController();
  final detailCtrl = TextEditingController();

  bool isSesuai = false;
  String alamat = "", detail = "";

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    alamatCtrl.dispose();
    detailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ice Cream"),
        centerTitle: true,
        backgroundColor: Color(0xfffA68078),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ListView(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 30),
                  Text("Sebelum memulai order, Masukkan detail alamat Anda"),
                  SizedBox(
                    height: 30,
                  ),
                  TextField(
                    maxLines: 1,
                    controller: alamatCtrl,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Alamat",
                      hintText: "Alamat Lengkap Anda",
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    maxLines: 2,
                    controller: detailCtrl,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Detail ",
                      hintText: "Detail alamat Anda",
                    ),
                  ),
                  ListTile(
                    title: Text("Apakah Sudah sesuai?"),
                    leading: Checkbox(
                      value: isSesuai,
                      onChanged: (bool? value) {
                        setState(() {
                          isSesuai = value!;
                        });
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 40,
                width: 20,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      alamat = alamatCtrl.text;
                      detail = detailCtrl.text;
                    });
                  },
                  child: Text("Submit"),
                  style: TextButton.styleFrom(
                      backgroundColor: Color(0xfffA68078),
                      primary: Colors.white),
                ),
              ),
              SizedBox(height: 30),
              Center(child: Text('Alamat :  $alamat')),
              Center(child: Text('Detail : $detail')),
              Center(
                  child:
                      Text('Inputan ${isSesuai ? "Sesuai" : "Tidak Sesuai"}'))
            ],
          ),
        ),
      ),
    );
  }
}
